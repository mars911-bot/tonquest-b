# TON Quest Telegram Bot

**Framework:** [grammY](https://grammy.dev/) (Node.js)

## How to run on Replit
1. Create a **Node.js Repl**.
2. Upload this ZIP or paste the code.
3. Add a Secret named `BOT_TOKEN` containing your BotFather token.
4. Press **Run**. Your bot should say “TON Quest Bot is running...” in the console.

## Commands
- `/start` — Welcome & main menu
- `/quests` — Shortcut to quests list
- `/rewards` — Placeholder
- `/leaderboard` — Placeholder
- `/seasonpass` — Payment instructions
- `/help` — Command list

## Next Steps
- Integrate TON Connect SDK for wallet login.
- Store user progress in Firebase/MongoDB.
- Automate Season Pass payments via smart contracts.