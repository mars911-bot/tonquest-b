// TON Quest Telegram Bot (Node.js + grammY)
//
// 1. Add a Secret in Replit named BOT_TOKEN with your BotFather token.
// 2. Click Run. The bot will go online.
// 3. Customize quests, rewards, and monetization as needed.

import { Bot, InlineKeyboard } from "grammy";

const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN) {
  console.error("❌ BOT_TOKEN is missing. Add it in Replit Secrets.");
  process.exit(1);
}

const bot = new Bot(BOT_TOKEN);

// 🗂️ In‑memory quest data (replace with DB)
const quests = [
  { id: 1, title: "Join TON Ecosystem Telegram", reward: "5 $QUEST" },
  { id: 2, title: "Follow @TonQuestTwitter", reward: "5 $QUEST" },
  { id: 3, title: "Swap on STON.fi", reward: "10 $QUEST" },
];

// 🚀 Commands
bot.command("start", async (ctx) => {
  await ctx.reply(
    "👋 Welcome to *TON Quest!*\n\nComplete quests. Earn tokens & NFTs. Rise on the leaderboard.",
    {
      parse_mode: "Markdown",
      reply_markup: new InlineKeyboard()
        .text("View Quests", "view_quests")
        .row()
        .url("Pitch Deck", "https://v0-tonquestlanding.vercel.app/#pitch"),
    }
  );
});

bot.callbackQuery("view_quests", async (ctx) => {
  let text = "🔥 *Daily Quests*\n\n";
  quests.forEach((q) => {
    text += `${q.id}. ${q.title} — _${q.reward}_\n`;
  });
  await ctx.editMessageText(text, { parse_mode: "Markdown" });
});

bot.command("quests", (ctx) => ctx.reply("Use the button below ⬇"));
bot.command("rewards", (ctx) => ctx.reply("🏆 Rewards: coming soon!"));
bot.command("leaderboard", (ctx) => ctx.reply("📊 Leaderboard: coming soon!"));
bot.command("seasonpass", (ctx) =>
  ctx.reply(
    "🎟️ *Season Pass* unlocks premium quests and rare NFTs.\nSend 10 TON to `EQC...YourAddress` and reply with the transaction hash for activation.",
    { parse_mode: "Markdown" }
  )
);
bot.command("help", (ctx) =>
  ctx.reply(
    "/start - Welcome\n/quests - List quests\n/rewards - Your rewards\n/leaderboard - Ranking\n/seasonpass - Go premium"
  )
);

// Start bot
bot.start();
console.log("🤖 TON Quest Bot is running...");